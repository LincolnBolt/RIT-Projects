//main.js
//Main method for app

"use strict";

var app = app || {}

app.main = {
	
	
	//canvas dimensions
	WIDTH: 640,
	HEIGHT: 480,
	//properties
	ENTITY: Object.freeze({
		BOX_WIDTH: 24,
		BOX_HEIGHT: 40,
		MOVE_SPEED: 20,
		NUM_ZOMBIES_START: 5,
		MAX_AMMO: 6,
		I_FRAMES: 300,
		AMMO_TIMER: 100
	}),
	canvas: undefined,
	ctx: undefined,
	lastTime: 0,
	debug: false,
	//zombies' particle explosion
	Emitter: undefined,
	explosion: undefined,
	paused: false,
	animationID: 0,
	gameState: undefined,
	lives: 3,
	wave: 0,
	numZombies: 0,
	score: 0,
	sound: undefined,
	
	player: {},
	crosshair: {},
	bullet: {},
	pickup: {},
	
	GAME_STATE: Object.freeze({
		TITLE: 0,
		PLAY: 1,
		OVER: 2
	}),
	
	ENTITY_STATE: Object.freeze({
		HUMAN: 0,
		ZOMBIE: 1,
		HUMAN_TAGGED: 2,
		ZOMBIE_TAGGED: 3
	}),
	entities: [],
	
	//methods
	init: function(){
		console.log("app.main.init() called");
		//initialize properties
		this.canvas = document.querySelector('canvas');
		this.canvas.width = this.WIDTH;
		this.canvas.height = this.HEIGHT;
		this.canvas.onmousedown = this.doMousedown.bind(this);
		this.canvas.onmousemove = this.doMousemove.bind(this);
		this.ctx = this.canvas.getContext('2d');
		this.gameState = this.GAME_STATE.TITLE;
		this.numZombies = this.ENTITY.NUM_ZOMBIES_START;
		//set up audio
		this.bgAudio = document.querySelector("#bgAudio");
		this.bgAudio.volume = 0.25;
		this.effectAudio = document.querySelector("#effectAudio");
		this.lives = 3;
		//set up player
		this.player = {};
		this.player.x = this.WIDTH/2;
		this.player.y = this.HEIGHT/2;
		this.player.width = this.ENTITY.BOX_WIDTH;
		this.player.height = this.ENTITY.BOX_HEIGHT;
		this.player.fillStyle = "#99F";
		this.player.mercy = false; //spawn invincibility
		this.player.iFrames = this.ENTITY.I_FRAMES;
		this.player.speed = this.ENTITY.MOVE_SPEED;
		this.player.ammo =  this.ENTITY.MAX_AMMO;
		this.player.sprite = document.getElementById("humanSprite");
		this.player.sprite.src = "media/human.png";
		this.player.gameState = this.ENTITY_STATE.HUMAN;
		Object.seal(this.player);
		//set up crosshairs
		this.crosshair = {};
		this.crosshair.x = this.WIDTH/2;
		this.crosshair.y = this.HEIGHT/2;
		Object.seal(this.crosshair);
		this.entities = this.createEntities(this.numZombies);
		//set up bullet
		this.bullet = {};
		this.bullet.active = false;
		this.bullet.x = 0;
		this.bullet.y = 0;
		this.bullet.width = 8;
		this.bullet.height = 8;
		this.bullet.xSpeed = 0;
		this.bullet.ySpeed = 0;
		Object.seal(this.bullet);
		//set up ammo pickup
		this.pickup = {};
		this.pickup.x = 0;
		this.pickup.y = 0;
		this.pickup.timer = this.ENTITY.AMMO_TIMER;
		this.pickup.width = 32;
		this.pickup.height = 24;
		this.pickup.fillStyle = "#2A2";
		this.pickup.sprite = document.getElementById("ammoSprite");
		this.pickup.active = false;
		Object.seal(this.pickup);
		//start the game loop
		this.update();
	},
	
	createEntities: function(num){
		var moveEntity = function(ctx){
			//this.x += this.xSpeed * this.speed * dt;
			//this.y += this.ySpeed * this.speed * dt;
		};
		var drawEntity = function(ctx){
			ctx.save();
			var w = this.width;
			var h = this.height;
			ctx.fillStyle = this.fillStyle;
			ctx.fillRect(this.x - w/2, this.y - h/2, w, h);
			ctx.restore();
		};
		var array = [];
		
		for(var i=0; i<num; i++){
			var z = {};
			var screenSide = Math.floor(getRandom(0, 3));
			switch(screenSide){
				case 0: //top
					z.y = -42;
					z.x = getRandom(0, this.WIDTH);
				break;
				case 1: //right
					z.x = this.WIDTH + 42;
					z.y = getRandom(0, this.HEIGHT);
				break;
				case 2: //bottom
					z.y = this.HEIGHT + 42;
					z.x = getRandom(0, this.WIDTH);
				break;
				case 3: //left
					z.x = -42;
					z.y = getRandom(0, this.HEIGHT);
				break;
			}
			//z.x = getRandom(0, this.WIDTH);
			//z.y = getRandom(0, this.HEIGHT);
			z.width = this.ENTITY.BOX_WIDTH;
			z.speed = 0.2 + this.wave / 50;
			z.height = this.ENTITY.BOX_HEIGHT;
			z.fillStyle = "#5F5";
			//particle explosion
			var explosion = new this.Emitter();
			explosion.red = 50;
			explosion.blue = 40;
			explosion.green = 40;
			explosion.minXspeed = explosion.minYspeed = -1;
			explosion.maxXspeed = explosion.maxYspeed = 1;
			explosion.lifetime = 20;
			explosion.expansionRate = 5;
			explosion.numParticles = 15;
			explosion.xRange = 1;
			explosion.yRange = 1;
			explosion.useCircles = true;
			explosion.useSquares = false;
			explosion.createParticles({x:z.x, y:z.y});
			z.explosion = explosion;
			z.explosionTimer = 30;
			z.draw = drawEntity;
			z.move = moveEntity;
			z.sprite = document.getElementById("zombieSprite");
			z.gameState = this.ENTITY_STATE.ZOMBIE;
			z.active = true;
			Object.seal(z);
			array.push(z);
		}
		return array;
	},
	
	playEffect: function(file){
		this.effectAudio.src = "media/" + file;
		this.effectAudio.play();
	},
	
	doMousedown: function(e){
		//fire if ammo > 0
		if(this.gameState == this.GAME_STATE.TITLE || this.gameState == this.GAME_STATE.OVER){
			this.wave = 1;
			this.lives = 3;
			this.numZombies = this.ENTITY.NUM_ZOMBIES_START;
			this.entities = this.createEntities(this.numZombies);
			this.player.x = this.WIDTH/2;
			this.player.y = this.HEIGHT/2;
			this.player.mercy = true;
			this.score = 0;
			this.player.ammo = this.ENTITY.MAX_AMMO;
			this.gameState = this.GAME_STATE.PLAY;
			this.sound.playBGAudio();
			return;
		}
		if(this.paused){
			this.resumeGame();
			return;
		}
		if(this.gameState == this.GAME_STATE.PLAY){
			if(this.player.ammo > 0 && !this.bullet.active){
			this.fireBullet();
			this.sound.playEffect("shoot.wav");
			this.player.ammo--;
			}
			else this.sound.playEffect("empty.wav");
		}
		
	},
	doMousemove: function(e){
		//move the crosshair
		var mouse = getMouse(e);
		this.moveCrosshair(mouse.x, mouse.y);
	},
	pauseGame: function(e){
		if(this.gameState === this.GAME_STATE.PLAY){
			this.paused = true;
			this.sound.stopBGAudio();
			cancelAnimationFrame(this.animationID);
			this.update();
		}
		
	},
	resumeGame: function(e){
		if(this.gameState === this.GAME_STATE.PLAY){
			cancelAnimationFrame(this.animationID);
			this.paused = false;
			this.sound.playBGAudio();
			this.update();
		}
		
	},
	toggleDebug: function(){
		this.debug = !this.debug;
	},
	update: function(){
		//1) Loop
		this.animationID = requestAnimationFrame(this.update.bind(this));
		//2) Paused
		if(this.paused){
			this.drawPause(this.ctx);
			return;
		}
		//3) DeltaTime
		var dt = this.calculateDeltaTime();
		//4) Update
		
		//game loop
		if(this.gameState == this.GAME_STATE.PLAY){
			//this.explosion.updateAndDraw()
			if(this.player.gameState == this.ENTITY_STATE.HUMAN){
				this.movePlayer();
				if(this.player.mercy){
					this.player.iFrames--;
					if(this.player.iFrames <= 0){
						this.player.mercy = false;
						this.player.iFrames = this.ENTITY.I_FRAMES;
					}
				}
			}
		
			this.moveZombies();
			this.moveBullet();
			this.checkCollisions();
			//spawn ammo crate when out of bullets
			if(!this.pickup.active){
				this.pickup.timer--;
			}
			if(this.pickup.timer <= 0){
				if(getRandom(0, 100) < 25){
					this.spawnAmmo();
				}
				this.pickup.timer = this.ENTITY.AMMO_TIMER;
			}
		
			//if all zombies are defeated, start next wave
			var allGone = true;
			for(var x = 0; x < this.entities.length; x++){
				if(this.entities[x].active){
					allGone = false;
				}
			}
			if(allGone){
				this.nextWave();
				this.numZombies ++;
				this.entities = this.createEntities(this.numZombies);
			}
		}
		
		//5) Draw
		this.ctx.fillStyle = "#585";
		this.ctx.fillRect(0,0,this.WIDTH,this.HEIGHT);
		//this.explosion.updateAndDraw(this.ctx, {x:100, y:100});
		if(this.gameState == this.GAME_STATE.PLAY){
			this.drawEntities(this.ctx);
			//animate invincibility
			if(this.player.gameState == this.ENTITY_STATE.HUMAN){
					if(this.player.mercy){
						if(this.player.fillStyle == "#99F"){
							this.player.fillStyle = "#FFF";
						}
						else if(this.player.fillStyle == "#FFF"){
							this.player.fillStyle = "#99F";
						}
				}
				else this.player.fillStyle = "#99F";
			}
		
			this.drawPlayer(this.ctx);
			if(this.bullet.active){
				this.drawBullet(this.ctx);
			}
		
			if(this.pickup.active){
				this.drawPickup(this.ctx);
			}
		
			this.drawCrosshair(this.ctx);
			
		}
		
		this.drawHUD(this.ctx);
		
		if(this.gameState == this.GAME_STATE.OVER){
			this.ctx.fillStyle = "rgba(50, 0, 0, 0.3)";
			this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
		}
	},
	drawPickup: function(ctx){
		var w = this.pickup.width;
		var h = this.pickup.height;
		ctx.fillStyle = this.pickup.fillStyle;
		ctx.drawImage(this.pickup.sprite, this.pickup.x - this.pickup.sprite.width/2,
		this.pickup.y - this.pickup.sprite.height/2);
		if(this.debug)ctx.fillRect(this.pickup.x - w/2, this.pickup.y - h/2, w, h);
	},
	
	drawPlayer: function(ctx){
		var w = this.player.width;
		var h = this.player.height;
		ctx.fillStyle = this.player.fillStyle;
		if(this.player.mercy){
			//draw a circle
			ctx.save();
			ctx.fillStyle = "rgba(128, 128, 255, " + this.player.iFrames / this.ENTITY.I_FRAMES +")";
			ctx.beginPath();
			ctx.arc(this.player.x, this.player.y, this.ENTITY.BOX_HEIGHT, 0, Math.PI * 2, false);
			ctx.closePath();
			ctx.fill();
			ctx.restore();
		}
		ctx.drawImage(this.player.sprite, this.player.x - this.player.sprite.width/2,
		this.player.y - this.player.sprite.height/2);
		if(this.debug)ctx.fillRect(this.player.x - w/2, this.player.y - h/2, w, h);
	},
	drawCrosshair: function(ctx){
		ctx.save();
		ctx.fillStyle = "#D00";
		ctx.beginPath();
		ctx.arc(this.crosshair.x, this.crosshair.y, 5, 0, Math.PI * 2, false);
		ctx.closePath();
		ctx.fill();
		ctx.restore();
	},
	drawBullet: function(ctx){
		ctx.save();
		ctx.fillStyle = "orange";
		ctx.beginPath();
		ctx.arc(this.bullet.x, this.bullet.y, this.bullet.width/2, 0, Math.PI * 2, false);
		ctx.closePath();
		ctx.fill();
		ctx.restore();
	},
	drawEntities: function(ctx){
		for(var i=0; i<this.entities.length; i++){
			var z = this.entities[i];
			if(!z.active){
				if(z.explosionTimer > 0){
					z.explosion.updateAndDraw(this.ctx, {x:z.x, y:z.y});
					z.explosionTimer--;
				}
				
				continue;
			} 
			ctx.drawImage(z.sprite,z.x - z.sprite.width/2, z.y - z.sprite.height/2);
			if(this.debug)z.draw(ctx);
		}
	},
	drawPause: function(ctx){
		ctx.save();
		ctx.fillStyle = "rgba(128,0,0,0.2)";
		ctx.fillRect(0, 0, this.WIDTH, this.HEIGHT);
		ctx.textAlign = "center";
		ctx.textBaseLine = "middle";
		this.fillText(ctx, "GAME PAUSED", this.WIDTH/2, this.HEIGHT/2 - 20, "48pt Anton", "black");
		this.fillText(ctx, "Press P or click to resume", this.WIDTH/2, this.HEIGHT/2 + 20, "24pt Boogaloo", "black");
		ctx.restore();
	},
	drawHUD: function(ctx){
		ctx.save();
		//fillText(string, x, y, css, color)
		if(this.gameState === this.GAME_STATE.TITLE){
			//center text
			//ctx.save();
			ctx.textBaseLine = "middle";
			ctx.textAlign = "center";
			this.fillText(this.ctx, "Vincent Lamicela presents", this.WIDTH/2, this.HEIGHT/2 - 100, "16pt Boogaloo", "white");
			this.fillText(this.ctx, "Zombie Attack!", this.WIDTH/2, this.HEIGHT/2 - 30, "bold 48pt Anton", "#D13");
			this.fillText(this.ctx, "Arrows or WASD to move (hold Shift to run)", this.WIDTH/2, this.HEIGHT/2, "16pt Boogaloo", "white");
			this.fillText(this.ctx, "Point and click to fire", this.WIDTH/2, this.HEIGHT/2 + 30, "16pt Boogaloo", "white");
			this.fillText(this.ctx, "Click anywhere to start", this.WIDTH/2, this.HEIGHT/2 + 80, "16pt Boogaloo", "white");
			this.fillText(this.ctx, "BGM: ''Noid Void 2'' from Yo Noid II: Enter the Void", this.WIDTH/2, this.HEIGHT - 15, "12pt Boogaloo", "white");
			//ctx.restore();
		}//end if
		if(this.gameState == this.GAME_STATE.PLAY){
			this.fillText(this.ctx, "Life: " + this.lives, 5, 20, "16pt VT323", "white");
			this.fillText(this.ctx, "Ammo: " + this.player.ammo, 5, 40, "16pt VT323", "white");
			this.fillText(this.ctx, "Wave: " + this.wave, 5, 60, "16pt VT323", "white");
			this.fillText(this.ctx, "Score: " + this.score, 5, 80, "16pt VT323", "white");
		
			if(this.debug){
				this.fillText(this.ctx, "DT: " + this.calculateDeltaTime().toFixed(3), 5, this.canvas.height - 20, "16pt VT323", "white");
				this.fillText(this.ctx, "I-Frames: " + this.player.iFrames, this.canvas.width - 150, this.canvas.height - 20, "16pt VT323", "white");
				this.fillText(this.ctx, "Ammo timer: " + this.pickup.timer, this.canvas.width - 150, this.canvas.height - 40, "16pt VT323", "white");
				this.fillText()
			}
		}//end if
		
		
		if(this.gameState == this.GAME_STATE.OVER){
			//You endured x waves before being overrun by the zombies
			ctx.textBaseLine = "middle";
			ctx.textAlign = "center";
			this.fillText(ctx, "You endured " + this.wave + " waves before you", this.WIDTH/2, this.HEIGHT/2 - 50, "24pt Anton", "white");
			this.fillText(ctx, "were overwhelmed by the zombies.", this.WIDTH/2, this.HEIGHT/2 - 10, "24pt Anton", "white");
			this.fillText(ctx, "Your score was " + this.score, this.WIDTH/2, this.HEIGHT/2 + 40, "24pt Anton", "white");
			this.fillText(ctx, "Click to play again", this.WIDTH/2, this.HEIGHT - 100, "32pt Boogaloo", "white");
			//Click to play again
		}
		ctx.restore();
	},
	fillText: function(ctx, string, x, y, css, color) {
		ctx.save();
		// https://developer.mozilla.org/en-US/docs/Web/CSS/font
		ctx.font = css;
		ctx.fillStyle = color;
		ctx.fillText(string, x, y);
		ctx.restore();
	},
	movePlayer: function(){
		var moveSpeed = 2;
		if(myKeys.keydown[myKeys.KEYBOARD.KEY_SHIFT]){
			moveSpeed *= 2;
		}
		if(myKeys.keydown[myKeys.KEYBOARD.KEY_UP] || myKeys.keydown[myKeys.KEYBOARD.KEY_W]){
			if(this.player.y - moveSpeed > 0)
			this.player.y -= moveSpeed;
		}
		if(myKeys.keydown[myKeys.KEYBOARD.KEY_DOWN] || myKeys.keydown[myKeys.KEYBOARD.KEY_S]){
			if(this.player.y + moveSpeed < this.canvas.height)
			this.player.y += moveSpeed;
		}
		if(myKeys.keydown[myKeys.KEYBOARD.KEY_LEFT] || myKeys.keydown[myKeys.KEYBOARD.KEY_A]){
			if(this.player.x - moveSpeed > 0)
			this.player.x -= moveSpeed;
		}
		if(myKeys.keydown[myKeys.KEYBOARD.KEY_RIGHT] || myKeys.keydown[myKeys.KEYBOARD.KEY_D]){
			if(this.player.x + moveSpeed < this.canvas.width)
			this.player.x += moveSpeed;
		}
	},
	fireBullet: function(){
		if(this.bullet.active == false){
			this.bullet.active = true;
			var mx = this.crosshair.x - this.player.x;
			var my = this.crosshair.y - this.player.y;
			var h = Math.sqrt(mx * mx + my * my);
			this.bullet.x = this.player.x;
			this.bullet.y = this.player.y;
			this.bullet.xSpeed = mx/h * 10;
			this.bullet.ySpeed = my/h * 10;
		}
	},
	moveZombies: function(){
		for(var i=0; i< this.entities.length; i++){
			var z = this.entities[i];
			//move towards the player
			if(!z.active){
				continue;
			}
			if(z.x > this.player.x){
				z.x -= z.speed;
			}
			if(z.x < this.player.x){
				z.x += z.speed;
			}
			if(z.y > this.player.y){
				z.y -= z.speed;
			}
			if(z.y < this.player.y){
				z.y += z.speed;
			}
		}
	},
	moveBullet: function(){
		if(this.bullet.active){
			this.bullet.x += this.bullet.xSpeed;
			this.bullet.y += this.bullet.ySpeed;
			//deactivate when out of bounds
			if(this.bullet.x < 0 || this.bullet.x > this.canvas.width
			|| this.bullet.y < 0 || this.bullet.y > this.canvas.height){
				this.bullet.active = false;
				this.xSpeed = 0;
				this.ySpeed = 0;
			}
		}
	},
	
	checkCollisions: function(){
		for(var i = 0; i < this.entities.length; i++){
			//check for player/enemy collision
			if(this.entities[i].active && boxesIntersect(this.player, this.entities[i])){
				//console.log("Collision detected");
				if(this.player.mercy == false){
					this.killPlayer();
					this.player.fillStyle = "red";
				}
			}
			if(this.entities[i].active && this.bullet.active && boxesIntersect(this.bullet, this.entities[i])){
				//kill zombie
				this.sound.playEffect("zombie_hit.wav");
				this.entities[i].active = false;
				this.bullet.active = false;
				this.score += 10;
			}
		}
		//pick up ammo crate
		if(boxesIntersect(this.player, this.pickup) && this.pickup.active){
			this.player.ammo += 6;
			this.pickup.active = false;
			this.sound.playEffect("ammo.wav");
		}
	},
	killPlayer: function(){
		this.sound.playEffect("human_hit.wav");
		this.lives--;
		this.player.gameState = this.ENTITY_STATE.HUMAN_TAGGED;
		setTimeout(this.respawn(), 3000);
		if(this.lives <= 0){
			this.gameState = this.GAME_STATE.OVER;
			this.sound.stopBGAudio();
			this.sound.playEffect("game_over.wav");
		}
	},
	respawn: function(){
		//console.log("respawned");
		this.player.x = this.canvas.width/2;
		this.player.y = this.canvas.height/2;
		this.player.width = this.ENTITY.BOX_WIDTH;
		this.player.height = this.ENTITY.BOX_HEIGHT;
		this.player.gameState = this.ENTITY_STATE.HUMAN;
		this.player.mercy = true;
	},
	nextWave: function(){
		this.wave++;
		this.sound.playEffect("next.wav");
		this.score += 50;
		//extra life every 10 waves
		if(this.wave % 10 == 0){
			this.lives++;
		}
	},
	moveCrosshair: function(mx, my){
		this.crosshair.x = mx;
		this.crosshair.y = my;
	},
	
	spawnAmmo: function(){
		this.pickup.active = true;
		this.pickup.x = getRandom(0, this.canvas.width);
		this.pickup.y = getRandom(0, this.canvas.height);
	},
	
	calculateDeltaTime: function(){
		var now, fps;
		now = performance.now();
		fps = 1000 / (now - this.lastTime);
		fps = clamp(fps, 12, 60);
		this.lastTime = now;
		return 1/fps;
	}
}; //end app.main