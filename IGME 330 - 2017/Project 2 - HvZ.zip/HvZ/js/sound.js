// sound.js
"use strict";
// if app exists use the existing copy
// else create a new object literal
var app = app || {};

// define the .sound module and immediately invoke it in an IIFE
app.sound = (function(){
	console.log("sound.js module loaded");
	var bgAudio = undefined;
	var shoot = "shoot.wav";
	var empty = "empty.wav";
	var hitZ = "zombie_hit.wav";
	var hitH = "human_hit.wav";
	var ammo = "ammo.wav";
	var next = "next.wav";
	var end = "game_over.wav";

	function init(){
		bgAudio = document.querySelector("#bgAudio");
		bgAudio.volume=0.25;
	}
	
	function playBGAudio(){
		bgAudio.play();
	}
		
	function stopBGAudio(){
		bgAudio.pause();
		bgAudio.currentTime = 0;
	}
	
	function playEffect(file){
		var effectSound = document.createElement('audio');
		effectSound.volume = 0.3;
		effectSound.src = "media/" + file;
		effectSound.play();
		//console.log("playEffect called");
	}
		
	// export a public interface to this module
	// TODO
	return{
		init: init,
		stopBGAudio: stopBGAudio,
		playBGAudio: playBGAudio,
		playEffect: playEffect
	};
}());